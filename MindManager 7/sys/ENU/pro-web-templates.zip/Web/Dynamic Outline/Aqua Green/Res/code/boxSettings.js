// exported by program to supply initial settings for boxes

var INITIAL_BOX_SETTINGS = [
	{name:"partialMap",	state:true}, 
	{name:"subTopics",	state:true}, 
	{name:"callouts",	state:true}, 
	{name:"comments",	state:false}, 
	{name:"relationships",	state:true}, 
	{name:"taskInformation",  state:true}, 
	{name:"textMarkers",  state:true},
	{name:"dataContainer",  state:true}, 
	{name:"legend",		state:true}
];